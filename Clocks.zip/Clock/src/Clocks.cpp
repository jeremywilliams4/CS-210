/*
 * Clocks.cpp
 *
 *  Created on: Jan 17, 2021
 *      Author: 1644701_snhu  Jeremy Williams
 */
#include <iostream>
#include <iomanip>
using namespace std;
//created variables to store hour, minute, second
int timeHr = 12;
int timeMin = 12;
int timeSec = 12;
//created variable for 24 hour time
int timeHr24 = 00;





int main() {
	int userInput;
//if statement to reset hour after surpassing 12 back to 01
    if (timeHr >12){
    	timeHr = timeHr -12;
    }
//if statement to reset hour after surpassing 23 back to 00
    if (timeHr24 > 23){
    	timeHr24 = timeHr24 -24;
    }
//output statements to display time in 12 and 24 hour formats
//setfill and setw are used to print leading zero
    cout << setfill('0') << setw(2) << timeHr << ":" << setfill('0') << setw(2) << timeMin << ":" << setfill('0') << setw(2) << timeSec;
	cout << "          " << setfill('0') << setw(2) << timeHr24 << ":" << setfill('0') << setw(2) << timeMin << ":" << setfill('0') << setw(2) << timeSec << endl << endl;
//conditional loop to be entered unless user presses 4
	while (userInput != 4){
//output statements to display menu to user
	cout << "Menu" << endl;
	cout << "Press '1' to add one hour" << endl;
	cout << "Press '2' to add one minute" << endl;
	cout << "Press '3' to add one second" << endl;
	cout << "Press '4' to Exit Program" << endl;
//gets user input
	cin >> userInput;

//increases hour value by one if user presses 1
	if (userInput == 1){
		timeHr += 1;
		timeHr24 += 1;
		if (timeHr24 > 23){
					timeHr24 = timeHr24 -24;
			}
		if (timeHr > 12){
					timeHr = timeHr -12;
			}
//output statements display new time
		cout << setfill('0') << setw(2) << timeHr << ":" << setfill('0') << setw(2) << timeMin << ":" << setfill('0') << setw(2) << timeSec;
		cout << "          " << setfill('0') << setw(2) << timeHr24 << ":" << setfill('0') << setw(2) << timeMin << ":" << setfill('0') << setw(2) << timeSec << endl << endl;
	}
//increases minute value by one if user presses2
	if (userInput == 2){
		timeMin +=1;
		if (timeHr24 > 23){
			timeHr24 = timeHr24 -24;
		}
		if (timeHr > 12){
			timeHr = timeHr -12;
	    }
		if (timeMin > 59){
			timeMin = timeMin - 60;
		}
//output statements display new time
		cout << setfill('0') << setw(2) << timeHr << ":" << setfill('0') << setw(2) << timeMin << ":" << setfill('0') << setw(2) << timeSec;
		cout << "          " << setfill('0') << setw(2) << timeHr24 << ":" << setfill('0') << setw(2) << timeMin << ":" << setfill('0') << setw(2) << timeSec << endl << endl;
	}
//increases second value by one if user presses 3
	if (userInput == 3){
		timeSec +=1;
		if (timeHr24 > 23){
			timeHr24 = timeHr24 -24;
		}
		if (timeHr > 12){
			timeHr = timeHr -12;
		}
		if (timeSec > 59){
			timeSec = timeSec - 60;
		}
//output statements display new time
		cout << setfill('0') << setw(2) << timeHr << ":" << setfill('0') << setw(2) << timeMin << ":" << setfill('0') << setw(2) << timeSec;
		cout << "          " << setfill('0') << setw(2) << timeHr24 << ":" << setfill('0') << setw(2) << timeMin << ":" << setfill('0') << setw(2) << timeSec << endl << endl;
	}
	}
//ends program and outputs 'Goodbye' if user presses 4
    if (userInput == 4){
    cout << "Goodbye.";


    }
}


